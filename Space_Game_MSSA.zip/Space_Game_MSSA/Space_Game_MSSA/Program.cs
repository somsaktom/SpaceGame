﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Space_Game_MSSA
{
    class Program
    {
        static void Main(string[] args)
        {
            mainManu();
        }

        static void mainManu()
        {
           
            Planets Planet1 = new Planets();
            Human Player = new Human();
            Player.name = "Willy";
            string playerName = Player.name;
            Planet1.PlanetName = "Earth 3.0";
            string planet1Name = Planet1.PlanetName;
            Planet1.Speech.WelcomeToPlanet(planet1Name, "Tom");
            Planet1.Speech.PlanetTalkingSale(playerName, "Gold");

            //Human Player = new Human();
            //Player.name = "Johnny";
            //Player.HumanSpeech.PlayerToPlanet(Player.name, "Mars");            //Planet1.PlanetToBuy(Planet1);

            //Planet1.Speech.PlanetAskPlayer(Player.name);
            //Player.HumanSpeech.PlayerToBuy();
            //Planet1.Speech.PlanetToBuy(Planet1.PlanetName, "Gold", 56.89M);



        }
    }
}
