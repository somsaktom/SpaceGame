﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Space_Game_MSSA
{
    public class PlanetsSpeech
    {
        public void WelcomeToPlanet(string Planet, string SalerName)
        {
            Console.WriteLine($"Traveler from a far off land, welcome to planet {Planet}");
            Console.WriteLine($"My name is {SalerName}");
            Console.WriteLine($"What bring you here to our lovely Planet, {Planet}");
            Console.ReadKey();
            Console.Clear();
        }
        public void PlanetTalkingSale(string characterName, string product)
        {
            Console.WriteLine($"{characterName}, our planet is specialized in producing {product}. ");
            Console.WriteLine();
            Console.WriteLine("do you want to buy or sell?");

            //Call the choice manue


        }

        public void PlanetToBuy(string planetName, string characterName)
        {
            decimal price = 0M;

            Console.WriteLine($"These are what I have to sell to you, {characterName}");
            Console.WriteLine($"I have this much of {characterName} coins at the price of {price:C} each.");
           // Console.WriteLine(planetName.PlanetGoodyBags.quantity(PlanetName));

        }

        public void PlanetToSell()
        {

        }

        public void PlanetToNegotiate()
        {

        }

        public void PlanetRejectOffer()
        {

        }

        public void PlanetAcceptOffer()
        {

        }

    }
}
