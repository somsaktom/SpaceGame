﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Space_Game_MSSA
{
    public class GoodyBag
    {
    

        public void quantity(PlanetsSpeech PlanetName)
        {
            //Console.WriteLine($"These are what {PlanetName} has to offer you in trade :\ngold = {PlanetName.Gold}\nsilver = {PlanetName.Silver}\ncopper = {PlanetName.Copper}\nbronze = {PlanetName.Bronze}\nbrass = {brass}");
        }
    }
}
