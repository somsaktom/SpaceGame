﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Space_Game_MSSA
{
    public class Planets
    {
        public string PlanetName { get; set; }
        public decimal money { get; set; }
        public int Gold { get; set; }
        public int Silver { get; set; }
        public int Brass { get; set; }
        public int Bronze { get; set; }
        public int Copper { get; set; }
        public GoodyBag PlanetGoodyBags { get; set; }
        public CommodityNames commodityNames;
        public PlanetNames planetNames;
        public Planets()
        {
            PlanetGoodyBags = new GoodyBag();
            this.Speech = new PlanetsSpeech();
            this.money = 1000;
            this.Gold = 50;
            this.Silver = 60;
            this.Brass = 10;
            this.Bronze = 90;
            this.Copper = 100;
        }
        public PlanetsSpeech Speech { get; set; }

        public double sell()
        {
            double result = 0;
            return result;
        }

        public double buy()
        {
            double result = 0;

            return result;
        }

        public double negotiation()
        {
            double result = 0;

            return result;
        }

        public double counterOffer()
        {
            double result = 0;

            return result;
        }

        
        enum PlanetSpecializedIn { Gold, Silver, Copper, Brass, Bronze }

    }
}