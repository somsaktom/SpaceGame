﻿using System;


namespace Space_Game_MSSA
{
    public enum PlanetNames
    {
        Mercury,
        Venus,
        Earth,
        Mars,
        Pluto
    }
}