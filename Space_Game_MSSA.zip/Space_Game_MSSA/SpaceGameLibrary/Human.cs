﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Space_Game_MSSA
{
    public class Human
    {
        public string name { get; set; }
        public decimal money { get; set; }
        public int gold { get; set; }
        public int silver { get; set; }
        public int brass { get; set; }
        public int bronze { get; set; }
        public int copper { get; set; }
        public HumanSpeech HumanSpeech { get; set; }
        public GoodyBag HumanGoodyBags { get; set; }
        public Human()
        {
            HumanGoodyBags = new GoodyBag();
            this.HumanSpeech = new HumanSpeech();
            this.money = 10000;
            this.gold = 100;
            this.silver = 500;
            this.brass = 300;
            this.bronze = 800;
            this.copper = 700;
        }

        public void PlayerSelect(string characterName)
        {
            
        //Call the manue for buy and sell
                 
        }
        
    
    }
}
